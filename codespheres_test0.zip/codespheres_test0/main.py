
import sys
from crew import CodespheresTest
from datetime import datetime

def run():
    """
    Run the crew.
    """
    inputs = {
        'topic': 'financial news',
        # 'current_year': str(datetime.now().year),
        'date': str(datetime.now().strftime("%Y-%m-%d"))
    }
    
    try:
        CodespheresTest().crew().kickoff(inputs=inputs)
    except Exception as e:
        raise Exception(f"An error occurred while running the crew: {e}")
