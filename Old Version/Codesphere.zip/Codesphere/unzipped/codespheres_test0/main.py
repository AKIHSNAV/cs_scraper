import sys
from crew import CodespheresTest
from datetime import datetime
import logging
import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Verify API key is loaded
if not os.getenv('OPENAI_API_KEY'):
    raise ValueError("OPENAI_API_KEY not found in environment variables")

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def run():
    """
    Run the crew.
    """
    logger.info("Starting the program...")
    inputs = {
        'topic': 'financial news',
        # 'current_year': str(datetime.now().year),
        'date': str(datetime.now().strftime("%Y-%m-%d"))
    }
    
    try:
        logger.info("Initializing CrewAI...")
        crew = CodespheresTest().crew()
        logger.info("Starting crew execution...")
        crew.kickoff(inputs=inputs)
    except Exception as e:
        logger.error(f"An error occurred: {str(e)}")
        raise Exception(f"An error occurred while running the crew: {e}")

if __name__ == "__main__":
    run()
