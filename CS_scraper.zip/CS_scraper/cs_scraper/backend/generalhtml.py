from playwright.sync_api import sync_playwright
import os
from datetime import datetime
import json
from flask import Flask, request, jsonify
from flask_cors import CORS
import sys
import time

app = Flask(__name__)
CORS(app)

@app.route('/')
def home():
    return jsonify({"status": "ok", "message": "Backend server is running"})

@app.route('/scrape', methods=['POST'])
def scrape():
    try:
        data = request.get_json()
        url = data.get('url')
        
        if not url:
            return jsonify({"error": "URL is required"}), 400
            
        result = scrape_interactive_page(url)
        return jsonify(result)
        
    except Exception as e:
        print(f"Error in scrape endpoint: {str(e)}", file=sys.stderr)
        return jsonify({"error": str(e)}), 500

def scrape_interactive_page(url, output_dir="scraped_pages"):
    # Create output directory if it doesn't exist
    os.makedirs(output_dir, exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    
    with sync_playwright() as playwright:
        try:
            # Launch browser
            browser = playwright.chromium.launch(headless=False)
            context = browser.new_context(
                user_agent='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
            )
            page = context.new_page()
            
            # Set a shorter timeout for navigation
            page.set_default_navigation_timeout(30000)  # 30 seconds
            page.set_default_timeout(30000)  # 30 seconds
            
            # Navigate to the page
            print(f"Accessing {url}...", file=sys.stdout)
            try:
                page.goto(url, wait_until='domcontentloaded', timeout=30000)
            except Exception as e:
                print(f"Navigation error: {str(e)}", file=sys.stderr)
                # Try to get content even if navigation failed
                pass
            
            # Wait for a short time for any dynamic content
            page.wait_for_timeout(2000)
            
            # Get initial HTML
            initial_html = page.content()
            with open(os.path.join(output_dir, f"initial_page_{timestamp}.html"), 'w', encoding='utf-8') as f:
                f.write(initial_html)
            
            # Find all clickable elements (tabs, buttons)
            clickable_elements = page.evaluate('''() => {
                // Function to check if element is visible
                function isVisible(elem) {
                    return !!(elem.offsetWidth || elem.offsetHeight || elem.getClientRects().length);
                }
                
                // Get all potentially clickable elements
                const elements = Array.from(document.querySelectorAll(
                    'button, [role="tab"], .tab, .nav-link, [data-toggle="tab"], a[href="#"]'
                ));
                
                return elements
                    .filter(el => isVisible(el))
                    .map(el => ({
                        text: el.textContent.trim(),
                        tag: el.tagName.toLowerCase(),
                        id: el.id || '',
                        class: el.className || ''
                    }));
            }''')
            
            # Get page title and meta description
            page_info = page.evaluate('''() => {
                return {
                    title: document.title,
                    description: document.querySelector('meta[name="description"]')?.content || '',
                    headings: Array.from(document.querySelectorAll('h1, h2, h3')).map(h => ({
                        level: h.tagName.toLowerCase(),
                        text: h.textContent.trim()
                    }))
                };
            }''')
            
            return {
                "status": "success",
                "html": initial_html,
                "clickable_elements": clickable_elements,
                "page_info": page_info,
                "timestamp": timestamp
            }
            
        except Exception as e:
            print(f"Error in scrape_interactive_page: {str(e)}", file=sys.stderr)
            return {"error": str(e)}
        finally:
            browser.close()

def wait_for_port(port, timeout=30):
    import socket
    start_time = time.time()
    while time.time() - start_time < timeout:
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.bind(('localhost', port))
                return True
        except OSError:
            time.sleep(0.1)
    return False

if __name__ == '__main__':
    # Wait for port 5001 to be available
    if not wait_for_port(5001):
        print("Error: Port 5001 is already in use", file=sys.stderr)
        sys.exit(1)
    
    print("Starting Flask server...", file=sys.stdout)
    app.run(debug=True, port=5001, use_reloader=False)