# Web Scraper Application

A full-stack web scraping application that can scrape interactive web pages and extract structured data.

## Prerequisites

- Python 3.8 or higher
- Node.js 14 or higher
- npm (Node Package Manager)

## Project Structure

```
cs_scraper/
├── backend/
│   ├── generalhtml.py
│   └── requirements.txt
└── frontend/
    ├── server.js
    ├── script.js
    ├── index.html
    ├── styles.css
    └── package.json
```

## Setup Instructions

### Backend Setup

1. Navigate to the backend directory:
   ```bash
   cd backend
   ```

2. Create and activate a virtual environment (recommended):
   ```bash
   # Windows
   python -m venv venv
   .\venv\Scripts\activate

   # Linux/Mac
   python3 -m venv venv
   source venv/bin/activate
   ```

3. Install Python dependencies:
   ```bash
   pip install -r requirements.txt
   ```

4. Install Playwright browsers:
   ```bash
   playwright install
   ```

### Frontend Setup

1. Navigate to the frontend directory:
   ```bash
   cd frontend
   ```

2. Install Node.js dependencies:
   ```bash
   npm install
   ```

## Running the Application

1. Start the application from the frontend directory:
   ```bash
   npm start
   ```

This will:
- Start the Express server on port 3000
- Automatically spawn the Python Flask backend on port 5000
- Open your browser to `http://localhost:3000`

## Usage

1. Open your browser and navigate to `http://localhost:3000`
2. Enter the URL you want to scrape in the input field
3. Click the "Scrape" button to start the scraping process
4. Wait for the results to be displayed
5. Use the extraction tools to process the scraped data

## Features

- Interactive web page scraping
- Automatic tab and button interaction
- HTML content extraction
- JSON data processing
- Download options for scraped data

## Troubleshooting

If you encounter any issues:

1. Make sure all dependencies are installed correctly
2. Check if both ports 3000 and 5000 are available
3. Ensure you have a stable internet connection
4. Check the browser console and server logs for error messages

## License

MIT License 